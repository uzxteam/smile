<?php
include "menu.php" ?>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="page-titles">
					<ol class="breadcrumb">
						<li class="breadcrumb-item active"><a href="javascript:void(0)">Operator</a></li>
						<li class="breadcrumb-item"><a href="javascript:void(0)">Reviews</a></li>
					</ol>
                </div>
			
				<div class="row">
					<div class="col-xl-12">
						<ul class="nav nav-pills review-tab">
							<li class="nav-item">
								<a href="#navpills-1" class="nav-link active" data-toggle="tab" aria-expanded="false">All Review</a>
							</li>
							<li class="nav-item">
								<a href="#navpills-2" class="nav-link" data-toggle="tab" aria-expanded="false">BEST</a>
							</li>
						</ul>
						<div class="tab-content">
							<div id="navpills-1" class="tab-pane active">
								<div class="card review-table">
									<div class="media align-items-center">
										<div class="checkbox mr-lg-4 mr-0 align-self-center">
											<div class="custom-control custom-checkbox checkbox-info">
												<input type="checkbox" class="custom-control-input" checked="" id="customCheckBox1" required="">
												<label class="custom-control-label" for="customCheckBox1"></label>
											</div>
										</div>
										<img class="mr-3 img-fluid rounded" width="90" src="images/doctors/6.jpg" alt="DexignZone">
										<div class="media-body d-lg-flex d-block row align-items-center">
											<div class="col-xl-4 col-xxl-5 col-lg-6 review-bx">
												<h3 class="fs-20 font-w600 mb-1"><a class="text-black" href="javascript:void(0);">Glee Smiley</a></h3>
												
												
											</div>
											<div class="col-xl-7 col-xxl-7 col-lg-6 text-dark mb-lg-0 mb-2">
											OPERATOR UzX Team
											</div>
										</div>
										<div class="media-footer d-sm-flex d-block align-items-center">
											<div class="disease mr-5">
												<span class="star-review ml-lg-3 mb-sm-0 mb-2 ml-0 d-inline-block">
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-orange"></i>
													
												</span>
											</div>
											<div class="edit ml-auto">
												<a href="javascript:void(0);" class="text-primary font-w600 mr-4">5.0</a>
												
											</div>
										</div>
									</div>
								</div>
								<div class="card review-table">
									<div class="media align-items-center">
										<div class="checkbox mr-lg-4 mr-0 align-self-center">
											<div class="custom-control custom-checkbox checkbox-info">
												<input type="checkbox" class="custom-control-input" checked="" id="customCheckBox2" required="">
												<label class="custom-control-label" for="customCheckBox2"></label>
											</div>
										</div>
										<img class="mr-3 img-fluid rounded" width="90" src="images/doctors/17.jpg" alt="DexignZone">
										<div class="media-body d-lg-flex d-block row align-items-center">
											<div class="col-xl-4 col-xxl-5 col-lg-6 review-bx">
												<h3 class="fs-20 font-w600 mb-1"><a class="text-black" href="javascript:void(0);">Alexia Kev</a></h3>
											
											</div>
											<div class="col-xl-7 col-xxl-7 col-lg-6 text-dark mb-lg-0 mb-2">
											OPERATOR UzX Team
											</div>
										</div>
										<div class="media-footer d-sm-flex d-block align-items-center">
											<div class="disease mr-5">
												<span class="star-review ml-lg-3 mb-sm-0 mb-2 ml-0 d-inline-block">
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-orange"></i>
													
												</span>
											</div>
											<div class="edit ml-auto">
												<a href="javascript:void(0);" class="text-primary font-w600 mr-4">4.9</a>
											
											</div>
										</div>
									</div>
								</div>
								<div class="card review-table">
									<div class="media align-items-center">
										<div class="checkbox mr-lg-4 mr-0 align-self-center">
											<div class="custom-control custom-checkbox checkbox-info">
												<input type="checkbox" class="custom-control-input" checked="" id="customCheckBox3" required="">
												<label class="custom-control-label" for="customCheckBox3"></label>
											</div>
										</div>
										<img class="mr-3 img-fluid rounded" width="90" src="images/doctors/18.jpg" alt="DexignZone">
										<div class="media-body d-lg-flex d-block row align-items-center">
											<div class="col-xl-4 col-xxl-5 col-lg-6 review-bx">
												<h3 class="fs-20 font-w600 mb-1"><a class="text-black" href="javascript:void(0);">Brian Lucky</a></h3>
												
											</div>
											<div class="col-xl-7 col-xxl-7 col-lg-6 text-dark mb-lg-0 mb-2">
											OPERATOR UzX Team
											</div>
										</div>
										<div class="media-footer d-sm-flex d-block align-items-center">
											<div class="disease mr-5">
												<span class="star-review ml-lg-3 mb-sm-0 mb-2 ml-0 d-inline-block">
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-orange"></i>
											
												</span>
											</div>
											<div class="edit ml-auto">
												<a href="javascript:void(0);" class="text-primary font-w600 mr-4">4.8</a>
											
											</div>
										</div>
									</div>
								</div>
								<div class="card review-table">
									<div class="media align-items-center">
										<div class="checkbox mr-lg-4 mr-0 align-self-center">
											<div class="custom-control custom-checkbox checkbox-info">
												<input type="checkbox" class="custom-control-input" checked="" id="customCheckBox4" required="">
												<label class="custom-control-label" for="customCheckBox4"></label>
											</div>
										</div>
										<img class="mr-3 img-fluid rounded" width="90" src="images/doctors/19.jpg" alt="DexignZone">
										<div class="media-body d-lg-flex d-block row align-items-center">
											<div class="col-xl-4 col-xxl-5 col-lg-6 review-bx">
												<h3 class="fs-20 font-w600 mb-1"><a class="text-black" href="javascript:void(0);">Don Jhon</a></h3>
											
											</div>
											<div class="col-xl-7 col-xxl-7 col-lg-6 text-dark mb-lg-0 mb-2">
											OPERATOR UzX Team
											</div>
										</div>
										<div class="media-footer d-sm-flex d-block align-items-center">
											<div class="disease mr-5">
												<span class="star-review ml-lg-3 mb-sm-0 mb-2 ml-0 d-inline-block">
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-gray"></i>
												</span>
											</div>
											<div class="edit ml-auto">
												<a href="javascript:void(0);" class="text-primary font-w600 mr-4">4.2</a>
											
											</div>
										</div>
									</div>
								</div>
								<div class="card review-table">
									<div class="media align-items-center">
										<div class="checkbox mr-lg-4 mr-0 align-self-center">
											<div class="custom-control custom-checkbox checkbox-info">
												<input type="checkbox" class="custom-control-input" checked="" id="customCheckBox5" required="">
												<label class="custom-control-label" for="customCheckBox5"></label>
											</div>
										</div>
										<img class="mr-3 img-fluid rounded" width="90" src="images/doctors/20.jpg" alt="DexignZone">
										<div class="media-body d-lg-flex d-block row align-items-center">
											<div class="col-xl-4 col-xxl-5 col-lg-6 review-bx">
												<h3 class="fs-20 font-w600 mb-1"><a class="text-black" href="javascript:void(0);">Olivia Smuth</a></h3>
											
											</div>
											<div class="col-xl-7 col-xxl-7 col-lg-6 text-dark mb-lg-0 mb-2">
											OPERATOR UzX Team
											</div>
										</div>
										<div class="media-footer d-sm-flex d-block align-items-center">
											<div class="disease mr-5">
												<span class="star-review ml-lg-3 mb-sm-0 mb-2 ml-0 d-inline-block">
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-gray"></i>
													<i class="fa fa-star text-gray"></i>
												</span>
											</div>
											<div class="edit ml-auto">
												<a href="javascript:void(0);" class="text-danger font-w600">3.1</a>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div id="navpills-2" class="tab-pane">
							<div class="card review-table">
									<div class="media align-items-center">
										<div class="checkbox mr-lg-4 mr-0 align-self-center">
											<div class="custom-control custom-checkbox checkbox-info">
												<input type="checkbox" class="custom-control-input" checked="" id="customCheckBox1" required="">
												<label class="custom-control-label" for="customCheckBox1"></label>
											</div>
										</div>
										<img class="mr-3 img-fluid rounded" width="90" src="images/doctors/6.jpg" alt="DexignZone">
										<div class="media-body d-lg-flex d-block row align-items-center">
											<div class="col-xl-4 col-xxl-5 col-lg-6 review-bx">
												<h3 class="fs-20 font-w600 mb-1"><a class="text-black" href="javascript:void(0);">Glee Smiley</a></h3>
												
												
											</div>
											<div class="col-xl-7 col-xxl-7 col-lg-6 text-dark mb-lg-0 mb-2">
											OPERATOR UzX Team
											</div>
										</div>
										<div class="media-footer d-sm-flex d-block align-items-center">
											<div class="disease mr-5">
												<span class="star-review ml-lg-3 mb-sm-0 mb-2 ml-0 d-inline-block">
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-orange"></i>
													<i class="fa fa-star text-orange"></i>
													
												</span>
											</div>
											<div class="edit ml-auto">
												<a href="javascript:void(0);" class="text-primary font-w600 mr-4">5.0</a>
												
											</div>
										</div>
									</div>
								</div>
								
						</div>
					</div>
				</div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright © Designed &amp; Developed by <a href="https://uzxteam.uz/" target="_blank">UzX Team</a> 2021</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->


    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="./vendor/global/global.min.js"></script>
	<script src="./vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	<script src="./js/custom.min.js"></script>
	<script src="./js/deznav-init.js"></script>
	
</body>
</html>